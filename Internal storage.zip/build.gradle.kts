plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.nethsara.aiplayer"; compileSdk = 34
 defaultConfig { applicationId = "com.nethsara.aiplayer"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0"; ndk { abiFilters += listOf("armeabi-v7a","arm64-v8a") } }
 buildTypes { release { isMinifyEnabled = false } }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
 buildFeatures { viewBinding = true }
}
dependencies {
 implementation("androidx.core:core-ktx:1.13.1")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("com.google.android.material:material:1.12.0")
 implementation("androidx.media3:media3-exoplayer:1.3.1")
 implementation("androidx.media3:media3-ui:1.3.1")
 implementation("androidx.media3:media3-common:1.3.1")
}
